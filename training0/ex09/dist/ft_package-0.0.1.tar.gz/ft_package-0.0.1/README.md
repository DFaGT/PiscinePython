# ft_package

`ft_package` は、リスト内で指定した要素が何回登場するかを数える
シンプルな関数を提供する Python パッケージです。

## インストール方法

1. ビルド済みの配布ファイル（wheel または sdist）がある場合:
   ```bash
   pip install ./dist/ft_package-0.0.1-py3-none-any.whl
